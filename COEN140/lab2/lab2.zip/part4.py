import numpy as np

print(np.identity(5))
